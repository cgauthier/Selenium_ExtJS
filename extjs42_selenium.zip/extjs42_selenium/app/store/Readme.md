This folder contains the stores
