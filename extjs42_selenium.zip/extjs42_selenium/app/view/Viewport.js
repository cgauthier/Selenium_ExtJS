Ext.define('TestApp.view.Viewport', {
    extend: 'Ext.container.Viewport',
    requires:[
        'TestApp.view.Login'
    ],

    layout: {
        type: 'fit'
    },

    items: [{
        xtype: 'login'
    }]
});
