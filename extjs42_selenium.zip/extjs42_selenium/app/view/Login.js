Ext.define('TestApp.view.Login', {
	extend : 'Ext.panel.Panel',
	requires : [],
	xtype : 'login',
	layout : {
		type : 'anchor'
	},

	title : "Demo App for Selenium Testing",

	items : [{
		xtype : "form",
		defaults : {
			labelSeparator : '',
			labelWidth : 70,
			width : 300,
			msgTarget : 'under',
			enableKeyEvents : true,
			allowBlank : false,
			margin : '10 0 10 0',
		},
		items : [{
			xtype : "textfield",
			fieldLabel : "Username",
			name : "username"
		}, {
			xtype : 'textfield',
			fieldLabel : "Password",
			inputType : "password",
			name : "password"
		}],
		buttons : [{
			xtype: 'button',
			text : "Sign In",
			action : 'submit',
			itemId : 'signInButton',
			margin : '0 33 0 0',
			formBind : true,
			disabled : true
		}]

	}]

});
