Ext.define('TestApp.controller.Login', {
	extend : 'Ext.app.Controller',
	views : ['Viewport', 'Login'],

	init : function() {
		var me = this;
		me.control({
			" button[action='submit']" : {
				"click" : "onSignInButtonClick"
			}
		});
	},

	onSignInButtonClick : function(btn) {
		debugger;
		var form = btn.up("form");
		var username = form.down("textfield[name='username']").getValue();
		var password = form.down("textfield[name='password']").getValue();
		var msg = "Username is: " + username + " and Password is: " + password;
		console.log(msg);
		Ext.Msg.alert("Captured Data", msg);
	}
});
