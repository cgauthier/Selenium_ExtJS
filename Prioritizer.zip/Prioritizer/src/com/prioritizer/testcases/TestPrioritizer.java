package com.prioritizer.testcases;

import java.util.Map;
import org.openqa.grid.internal.listeners.Prioritizer;

public class TestPrioritizer implements Prioritizer {

	@Override
	public int compareTo(Map<String, Object> test1, Map<String, Object> test2) {
		int p1 = Integer.parseInt((String) test1.get("_important"));
		int p2 = Integer.parseInt((String) test2.get("_important"));
		
		if(p1 == p2) {
			return 0;
		} else if(p1 > p2) {
			return -1;
		} else {
			return 1;
		}
	}

}
